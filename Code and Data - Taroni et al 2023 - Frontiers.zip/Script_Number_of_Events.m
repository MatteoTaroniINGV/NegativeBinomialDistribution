% Script for the paper Taroni et al. 2023 - Frontiers
%
% 1) compute the number of events distribution in selected time window;
% 2) test the Poisson and Negative Binomial distributions using the
%    chisquare test;
% 3) compute the Akike Information Criterion to find the best model;


% clear the workspace
clear all ; home


%%% Input catalog

% load the catalog in ZMAP format
 Cat = load( 'CMT_Catalog_1980_2019_Depth50km.txt' ) ;
%Cat = load( 'CMT_Catalog_1980_2019_Depth50km_Japan.txt' ) ;
%Cat = load( 'HORUS_1960_2021_Mw4_Depth30km_InsideItaly.txt' ) ;




%%% Input for computation

% time interval and magnitude range (they must be coherent with the
% selected catalog)
Mmin    = 6.5 ;   % minimum magnitude
Y_Start = 1980 ;  % starting year for the selection
Y_End   = 2019 ;  % ending year for the selection (is included)

% time window (in days)
TW = 7 ;




%%% Computation

% select the events in the catalog according to time interval and magnitude range
Cat_Ok = Cat( Cat(:,6) >= Mmin & Cat(:,3) >= Y_Start & Cat(:,3) <= Y_End , : ) ;

% length of the catalog (in days)
Cat_Length = datenum( [ Y_End , 12 , 31 ] ) - datenum( [ Y_Start , 1 , 1 ] ) + 1 ;

% number of time windows
Num_TW = floor( Cat_Length / TW ) ;

% preallocation of the vector containing the number of events
Num_Ev = zeros( 1 , Num_TW ) ;

% loop to count the number of events in each time window
for i = 1 : Num_TW
    
    % set the starting time (in days)
    Starting_Time = datenum( [ Y_Start , 1 , 1 , 0 , 0 , 0 ] ) ;
    
    % find the events in the i-th time window
    Num_Ev( i ) = sum( datenum( Cat_Ok( : , [ 3 : 5 , 8 : 10 ] ) ) >= Starting_Time + TW*( i - 1 ) & ...
                       datenum( Cat_Ok( : , [ 3 : 5 , 8 : 10 ] ) ) <  Starting_Time + TW*( i ) ) ;
                   
end




%%% Test for Poisson distribution

% number of bins
bins = 0 : 1 : max( Num_Ev) ;

% observations for each bin (it uses the 'histc' function, then the last
% bin must be removed)
Obs    = histc( Num_Ev , [ 0 : 1 : max( Num_Ev) + 1 ] - 0.5 ) ;
Obs_Ok = Obs( 1 : end - 1 ) ; 

% estimation of the Lambda for the Poisson distribution
lambdaHat = poissfit(Num_Ev);

% expected number of events in each bin
expCountsP = length(Num_Ev)*poisspdf( bins , lambdaHat ) ;

% Chi-square goodness of fit test
[ H_test , P_test , ST_test ] = chi2gof(bins,'ctrs',bins,'frequency',Obs_Ok,'expected',expCountsP,'nparams',1) ;

% show the p-value of the test
Pvalue_Poisson = P_test

% AIC for Poisson distribution
AIC_Pois = 2*1 - 2*sum( log( poisspdf( Num_Ev , lambdaHat ) ) )




%%% Test for Negative Binomial distribution

% estimation of the parameters for the negative binomial distribution
paramHat = nbinfit(Num_Ev);

% expected number of events in each bin
expCountsNB = length(Num_Ev)*nbinpdf( bins , paramHat(1) , paramHat(2) ) ;

% Chi-square goodness of fit test
[ H_test , P_test , ST_test ] = chi2gof(bins,'ctrs',bins,'frequency',Obs_Ok,'expected',expCountsNB,'nparams',2) ;

% show the p-value of the test
Pvalue_NB = P_test

% AIC for Negative Binomial distribution
AIC_NB = 2*2 - 2*sum( log( nbinpdf( Num_Ev , paramHat(1) , paramHat(2) ) ) )


 

%%% Plot of the results 

% plot of the observed and expected number of events in each bin (Poisson)
bar( bins , Obs_Ok )
hold on
plot( bins , expCountsP  , 'r'   , 'LineWidth' , 3 )

% plot of expected number of events in each bin (Negative Binomial)
plot( bins , expCountsNB , '--k' , 'LineWidth' , 3 )
    
% plot options
set( gca , 'Fontsize' , 14 )
xlabel( 'Number of Events' )
ylabel( 'Frequencies' )
legend( 'Observations' , 'Poisson' , 'Negative Binomial' )


    
    